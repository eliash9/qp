

<?php $__env->startSection('content'); ?>
  

    <section class="py-10 overflow-hidden">
        <div class="container mx-auto flex justify-center">
            <div class="w-full py-0 px-5 space-y-5">
                <div class="flex justify-center items-center pb-5">
                    <div class="w-auto py-1.5 px-2">
                        <h2 class="md:text-2xl text-lg font-sans font-semibold text-center text-black">
                            Selamat anda sudah menyelesaikan semua soal
                        </h2>
                    </div>
                </div>                     
                <!-- New Table -->
                <div class="w-full overflow-hidden rounded-lg shadow-xs">
                    <div class="w-full overflow-x-auto bg-color-F4F2DE px-2 py-2">
                        <table class="w-full whitespace-no-wrap">
                            <thead>
                                <tr class="text-xs font-semibold tracking-wide text-left text-black uppercase border-b border-gray-400">
                                    <th class="px-4 py-3">No</th>
                                    <th class="px-4 py-3">Soal</th>
                                    <th class="px-4 py-3">Jawaban</th>
                                    <th class="px-4 py-3">Keterangan</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white-fafafa divide-y divide-gray-400">

                                <?php $no=0; ?>
                                <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $no++; ?>

                                <tr class="text-black">
                                    <td class="px-4 py-3 text-sm">
                                        <?php echo e($no); ?>

                                    </td>
                                    <td class="px-4 py-3 text-sm">
                                        <?php echo $row->question; ?> 
                                    </td>
                                    <td class="px-4 py-3 text-sm">
                                        <?php echo e($row->answer); ?>

                                    </td>
                                    <td class="px-4 py-3 text-sm">
                                        <?php echo e($row->desc); ?>

                                    </td>
                                </tr>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>       
        </div>
    </section>

    <section class="py-10 overflow-hidden h-screen">
        <div class="container mx-auto flex justify-center">
            <div class="pb-1 px-10 max-w-xl">
                <div class="space-y-2 rounded-md shadow-sm flex flex-col justify-center items-center">
                    <a href="<?php echo e(url('/pelajar/room/'.$done->id.'/standing')); ?>" class="px-4 py-2 text-lg text-blue-2F308B group relative flex w-auto justify-center rounded-lg hover:opacity-50 bg-blue-400">
                        Ranking
                    </a>
                    <a href="<?php echo e(url('/pelajar')); ?>" class="px-4 py-2 text-lg text-blue-2F308B group relative flex w-auto justify-center rounded-lg hover:opacity-50 bg-green-400">
                        Home
                    </a>
                </div>
            </div>            
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pelajar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\qp\resources\views/pelajar/done.blade.php ENDPATH**/ ?>