

<?php $__env->startSection('content'); ?>
  

    <section class="py-20 overflow-hidden">
        <div class="container mx-auto flex justify-center">
            <div class="py-0 w-full px-5 space-y-5">    
                <div class="flex justify-center items-center">
                    <div class="w-auto bg-color-F4F2DE py-1.5 px-2 rounded-lg shadow">
                        <h2 class="md:text-2xl text-lg font-sans font-semibold text-center text-black">
                           Global Ranking
                        </h2>
                    </div>
                </div>                
                <!-- New Table -->
                <div class="w-full overflow-hidden rounded-lg shadow-xs">
                    <div class="w-full overflow-x-auto bg-color-F4F2DE px-2 py-2">
                        <table class="w-full whitespace-no-wrap">
                            <thead>
                                <tr class="text-xs font-semibold tracking-wide text-left text-black border-gray-400 uppercase border-b">
                                    <th class="px-4 py-3">No</th>
                                    <th class="px-4 py-3">Name</th>
                                    <th class="px-4 py-3">Score</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white-fafafa divide-y divide-gray-400">

                                <?php $no=0; ?>
                                <?php $__currentLoopData = $stand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $no++; ?>

                                <tr class="text-black">
                                    <td class="px-4 py-3 text-sm">
                                        <?php echo e($no); ?>

                                    </td>
                                    <td class="px-4 py-3 text-sm">
                                        <?php echo e($row->username); ?>

                                    </td> 
                                    <td class="px-4 py-3 text-sm">
                                        <?php echo e($row->total); ?>

                                    </td>
                                </tr>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>        
        </div>
    </section>

    <section class="py-20 overflow-hidden">
        <div class="container mx-auto flex justify-center">
            <div class="py-0 w-full px-5 space-y-5">    
                <div class="flex justify-center items-center">
                    <div class="w-auto bg-color-F4F2DE py-1.5 px-2 rounded-lg shadow">
                        <h2 class="md:text-2xl text-lg font-sans font-semibold text-center text-black">
                            Percentage
                        </h2>
                    </div>
                </div>                
                <!-- New Table -->
                <div class="w-full overflow-hidden rounded-lg shadow-xs">
                    <div class="w-full overflow-x-auto bg-color-F4F2DE px-2 py-2">
                        <table class="w-full whitespace-no-wrap">
                            <thead>
                                <tr class="text-xs font-semibold tracking-wide text-left text-black border-gray-400 uppercase border-b">
                                    <th class="px-4 py-3">Soal</th>
                                    <th class="px-4 py-3">True</th>
                                    <th class="px-4 py-3">False</th>
                                    <th class="px-4 py-3">User</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white-fafafa divide-y divide-gray-400">

                                <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr class="text-black">
                                    <td class="px-4 py-3 text-sm">
                                        <?php echo $row->question; ?>

                                    </td> 
                                    <td class="px-4 py-3 text-sm">
                                        <?php echo e($row->getCorrectAnswerPercentage()); ?>

                                    </td>
                                    <td class="px-4 py-3 text-sm">
                                        <?php echo e($row->getWrongAnswerPercentage()); ?>

                                    </td>
                                    <td class="px-4 py-3 text-sm">
                                        <?php echo e($row->getUserPlays()); ?> user
                                    </td>
                                </tr>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="flex justify-end items-center">
                    <a href="<?php echo e(url('guru')); ?>" type="button" class="group relative flex w-auto justify-center rounded-md bg-orange-400 px-3 py-2 text-sm font-semibold text-white hover:bg-gray-400 shadow shadow-gray-400 duration-200">
                        < <span class="px-2"> | </span> Back
                    </a>
                </div>   
            </div>        
        </div>
    </section>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\qp\resources\views/guru/rangking.blade.php ENDPATH**/ ?>