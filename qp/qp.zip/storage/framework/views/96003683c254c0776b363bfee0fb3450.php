<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link rel="icon" href="<?php echo e(asset ('img/logo.png')); ?>">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/uicons-regular-straight/css/uicons-regular-straight.css'>
    <title>Play Quiz</title>
</head>

<body class="bg-gradient-to-r bg-blue-2F308B">
    
    <nav id="navbar" class="flex flex-wrap items-center justify-between w-full space-x-4 py-4 px-5 md:px-10 text-lg text-black-1E1E1E bg-white-fafafa mt-0 z-10 top-0">
        <svg xmlns="http://www.w3.org/2000/svg" id="menu-button" class="h-6 w-6 cursor-pointer md:hidden block text-black-1E1E1E shadow-lg" fill="none" viewBox="0 0 24 24" stroke="currentColor" >
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
        </svg>        
        
        <div class="flex md:flex-row space-x-2">
            <?php if(auth()->guard()->check()): ?>
            <h2 class="font-sans font-semibold text-center text-black text-lg">
                <?php echo e(auth()->user()->username); ?>

            </h2>
            <?php endif; ?>
        </div>
    </nav>

    <section class="py-20 overflow-hidden h-screen">
        <div class="container mx-auto flex justify-center">
            <div class="py-0 w-full px-5 space-y-10">        
                <div class="flex flex-col justify-center items-center space-y-10">
                    <h2 class="text-center text-xl font-sans font-bold tracking-widest text-black uppercase">
                        <?php echo e($detail->room); ?>

                    </h2>
                    <a href="<?php echo e(url('/pelajar/room/'.$detail->id.'/room_post')); ?>" class="px-7 py-2 text-2xl text-white group relative flex w-auto justify-center rounded-lg hover:opacity-50 bg-green-400">
                        Play
                    </a>
                </div>

                <div class="flex justify-end items-center">
                    <a href="<?php echo e(url('/pelajar')); ?>" type="button" class="group relative flex w-auto justify-center rounded-md bg-orange-400 px-3 py-2 text-sm font-semibold text-white hover:bg-gray-400 shadow shadow-gray-400 duration-200">
                        < <span class="px-2"> | </span> Back
                    </a>
                </div>   
            </div>        
        </div>
    </section>

    <?php echo e(View::make('footer')); ?>


</body>


<script type="text/javascript">
    const button = document.querySelector('#menu-button');
    const menu = document.querySelector('#menu');
    button.addEventListener('click', () => {
    menu.classList.toggle('hidden');
    });
</script>

<script type="text/javascript">
    const dropdown = document.querySelector('#dropdown-button');
    const dropmenu = document.querySelector('#dropdown-menu');
    dropdown.addEventListener('click', () => {
    dropmenu.classList.toggle('hidden');
    });
</script>

</html><?php /**PATH C:\xampp\htdocs\quizplay\resources\views/pelajar/room.blade.php ENDPATH**/ ?>