<footer id="Footer" class="bg-white overflow-hidden">
    <div class="mx-auto w-full py-2 px-5">    
        <p class="mx-auto max-w-md text-center text-sm leading-relaxed text-black">
            Copyright &copy; 2023 by Bayu Traitmojo
        </p>
    </div>
</footer><?php /**PATH E:\2023\LARAVEL\qp\qp\resources\views/footer.blade.php ENDPATH**/ ?>