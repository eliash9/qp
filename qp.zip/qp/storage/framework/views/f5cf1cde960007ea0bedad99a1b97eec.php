<div class="alert-danger">
    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(Session::has('alert-'.$msg)): ?>
            <p class="alert alert-<?php echo e($msg); ?>">
                <?php echo e(Session::get('alert-'.$msg)); ?> 
                <a href="" class="close" data-dismiss="alert" aria-label="close">
                    &times;
                </a>
            </p>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="py-2 px-2 bg-red">
                <p class="text-sm text-red-500 text-center"> <?php echo e($error); ?> </p>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<?php if(count($errors) < 0): ?>
<div class="alert alert-success">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="py-2 px-2 bg-green-600">
                <p class="text-sm text-green-600 text-center"> <?php echo e($error); ?> </p>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\quizplay\resources\views/errors/message.blade.php ENDPATH**/ ?>